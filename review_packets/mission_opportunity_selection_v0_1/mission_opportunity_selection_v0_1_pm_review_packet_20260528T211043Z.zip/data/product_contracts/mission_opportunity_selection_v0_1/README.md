# Mission Opportunity Selection Contracts v0.1

Status: PM accepted implementation-readiness slice. Offline synthetic fixtures only.

This package defines the schema layer for selecting ranked mission opportunities. It does not implement runtime selection, connect to live listener evidence, generate production missions, mutate canonical graph truth, or reuse Mission Construction Contract v0.2 as the selector schema.

## Contracts

- `schemas/mission_type_registry_v0_1.schema.json`
- `schemas/evidence_rollup_v0_1.schema.json`
- `schemas/mission_opportunity_blob_v0_1.schema.json`
- `schemas/selector_output_v0_1.schema.json`

## TypeScript Types

- `types/mission_type_registry_v0_1.ts`
- `types/evidence_rollup_v0_1.ts`
- `types/mission_opportunity_blob_v0_1.ts`
- `types/selector_output_v0_1.ts`
- `types/index.ts`

## Fixtures

Positive fixtures live in `fixtures/`.

Negative fixtures live in `fixtures/negative/` and are expected to fail validation or domain gates.

## Validation

Use the repo virtualenv so `jsonschema` is available:

```sh
.venv/bin/python scripts/validate_mission_opportunity_selection_v0_1.py
.venv/bin/python data/product_contracts/mission_opportunity_selection_v0_1/tests/fixture_contract_tests_v0_1.py
```

## Locked Boundaries

- Survey `ok` is no signal and must not contribute preference or non-failure evidence.
- Mission/song-review `ok` is weak non-failure evidence, not positive preference.
- Output is ranked opportunity blobs only, not mission content.
- Runtime use, production mission generation, canonical graph mutation, and listener preference inference from affinity similarity remain blocked.
