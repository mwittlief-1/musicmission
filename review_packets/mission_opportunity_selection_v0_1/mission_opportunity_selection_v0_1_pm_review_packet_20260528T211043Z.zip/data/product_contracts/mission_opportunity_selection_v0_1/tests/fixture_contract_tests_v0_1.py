#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path


CONTRACT_DIR = Path(__file__).resolve().parents[1]
REPO_ROOT = CONTRACT_DIR.parents[2]
sys.path.insert(0, str(REPO_ROOT / "scripts"))

from validate_mission_opportunity_selection_v0_1 import (  # noqa: E402
    EXPECTED_MISSION_TYPES,
    FORBIDDEN_CONTENT_KEYS,
    NEGATIVE_CASES,
    TYPE_FILES,
    validate_contracts,
)


def load_json(path: Path) -> object:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def walk(value: object) -> object:
    if isinstance(value, dict):
        for child in value.values():
            yield from walk(child)
        yield value
    elif isinstance(value, list):
        for child in value:
            yield from walk(child)


def main() -> int:
    failures: list[str] = []

    result = validate_contracts()
    failures.extend(result.failures)

    schema_paths = [
        CONTRACT_DIR / "schemas/mission_type_registry_v0_1.schema.json",
        CONTRACT_DIR / "schemas/evidence_rollup_v0_1.schema.json",
        CONTRACT_DIR / "schemas/mission_opportunity_blob_v0_1.schema.json",
        CONTRACT_DIR / "schemas/selector_output_v0_1.schema.json",
    ]
    for schema_path in schema_paths:
        schema = load_json(schema_path)
        schema_id = schema.get("$id", "")
        if not str(schema_id).startswith("https://cartenza.local/contracts/"):
            failures.append(f"{schema_path.name} schema id must use the Cartenza contract namespace")

    registry = load_json(CONTRACT_DIR / "fixtures/mission_type_registry_sample_v0_1.json")
    mission_types = [entry["mission_type"] for entry in registry["mission_types"]]
    if mission_types != EXPECTED_MISSION_TYPES:
        failures.append("registry fixture mission type set does not match v0.1 approved list")

    evidence = load_json(CONTRACT_DIR / "fixtures/evidence_rollup_sample_v0_1.json")
    semantics = evidence["reaction_semantics"]
    if semantics["survey_ok_signal_class"] != "no_signal":
        failures.append("survey ok must remain no_signal")
    if semantics["mission_ok_signal_class"] != "weak_non_failure":
        failures.append("mission ok must remain weak_non_failure")
    if semantics["mission_ok_is_positive_preference"] is not False:
        failures.append("mission ok must not become positive preference")

    selector = load_json(CONTRACT_DIR / "fixtures/selector_output_sample_v0_1.json")
    for node in walk(selector):
        if isinstance(node, dict):
            forbidden = FORBIDDEN_CONTENT_KEYS.intersection(node)
            if forbidden:
                failures.append(f"selector fixture includes forbidden mission content keys: {sorted(forbidden)}")

    if len(NEGATIVE_CASES) < 7:
        failures.append("negative fixture coverage must include semantic, runtime, content, and graph-context gates")

    for type_file in TYPE_FILES:
        if not type_file.exists():
            failures.append(f"missing TypeScript type file: {type_file.relative_to(REPO_ROOT)}")

    if failures:
        print("FAIL Mission Opportunity Selection v0.1 fixture tests")
        for failure in failures:
            print(f"- {failure}")
        return 1

    print("PASS Mission Opportunity Selection v0.1 fixture tests")
    print("PASS offline schemas, TypeScript types, fixtures, and negative gates validate")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
