import type { MissionTypeV01 } from "./mission_type_registry_v0_1";
import type { MissionOpportunityBlobV01 } from "./mission_opportunity_blob_v0_1";

export type SelectorOutputContractVersionV01 = "selector_output_v0_1";

export interface SelectorOutputV01 {
  contract_version: SelectorOutputContractVersionV01;
  fixture_status: "synthetic_contract_fixture";
  selector_run_id: string;
  created_at: string;
  runtime_allowed: false;
  production_mission_generation_allowed: false;
  canonical_graph_mutation_allowed: false;
  listener_preference_inference_from_affinity_allowed: false;
  opportunity_only: true;
  source_registry_ref: string;
  source_evidence_rollup_ref: string;
  global_top_k_opportunities: 25;
  selector_audit: SelectorAuditV01;
  ranked_opportunities: MissionOpportunityBlobV01[];
}

export interface SelectorAuditV01 {
  selection_mode: "offline_synthetic_fixture";
  mission_types_sorted_by_descending_ceiling: boolean;
  global_heap_maintained: boolean;
  heap_max_size: 25;
  early_stop_applied: boolean;
  early_stop_reason: string | null;
  remaining_ceiling_at_stop: number | null;
  cutoff_score: number | null;
  candidate_generation_summaries: SelectorCandidateGenerationSummaryV01[];
  audit_notes: string[];
}

export interface SelectorCandidateGenerationSummaryV01 {
  mission_type: MissionTypeV01;
  generator_id: string;
  eligible_candidate_count: number;
  emitted_candidate_count: number;
  floor_failed_candidate_count: number;
  pruned_candidate_count: number;
  cap_applied: boolean;
  cap_value: number;
}
