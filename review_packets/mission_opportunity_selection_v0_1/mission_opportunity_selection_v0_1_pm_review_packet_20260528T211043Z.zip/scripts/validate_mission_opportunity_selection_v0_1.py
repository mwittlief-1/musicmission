#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable


REPO_ROOT = Path(__file__).resolve().parents[1]
CONTRACT_DIR = REPO_ROOT / "data/product_contracts/mission_opportunity_selection_v0_1"
SCHEMA_DIR = CONTRACT_DIR / "schemas"
FIXTURE_DIR = CONTRACT_DIR / "fixtures"
NEGATIVE_FIXTURE_DIR = FIXTURE_DIR / "negative"
TYPE_DIR = CONTRACT_DIR / "types"

REGISTRY_SCHEMA = SCHEMA_DIR / "mission_type_registry_v0_1.schema.json"
EVIDENCE_SCHEMA = SCHEMA_DIR / "evidence_rollup_v0_1.schema.json"
OPPORTUNITY_SCHEMA = SCHEMA_DIR / "mission_opportunity_blob_v0_1.schema.json"
SELECTOR_SCHEMA = SCHEMA_DIR / "selector_output_v0_1.schema.json"

REGISTRY_FIXTURE = FIXTURE_DIR / "mission_type_registry_sample_v0_1.json"
EVIDENCE_FIXTURE = FIXTURE_DIR / "evidence_rollup_sample_v0_1.json"
OPPORTUNITY_FIXTURE = FIXTURE_DIR / "mission_opportunity_blob_sample_v0_1.json"
SELECTOR_FIXTURE = FIXTURE_DIR / "selector_output_sample_v0_1.json"

EXPECTED_MISSION_TYPES = [
    "initial_profile_survey",
    "family_survey",
    "archetype_survey",
    "gateway_test",
    "song_to_archetype_test",
    "artist_depth_test",
    "album_container_test",
    "archetype_depth_test",
    "exception_scope_test",
    "false_nearby_test",
    "context_dependence_test",
    "bridge_test",
    "boundary_test",
    "evidence_repair_test",
]

FORBIDDEN_CONTENT_KEYS = {
    "mission_content",
    "mission_items",
    "mission_title",
    "mission_description",
    "playlist",
    "playback_plan",
    "catalog_resolution",
    "runtime_lifecycle",
    "production_mission",
}

BLOCKED_FALSE_KEYS = {
    "runtime_allowed",
    "runtime_listener_evidence_connected",
    "production_mission_generation_allowed",
    "canonical_graph_mutation_allowed",
    "listener_preference_inference_from_affinity_allowed",
}

TYPE_FILES = [
    TYPE_DIR / "mission_type_registry_v0_1.ts",
    TYPE_DIR / "evidence_rollup_v0_1.ts",
    TYPE_DIR / "mission_opportunity_blob_v0_1.ts",
    TYPE_DIR / "selector_output_v0_1.ts",
    TYPE_DIR / "index.ts",
]

NEGATIVE_CASES = [
    (
        "survey ok cannot count as signal",
        EVIDENCE_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "survey_ok_counts_as_signal_evidence_rollup_v0_1.json",
    ),
    (
        "mission ok must be weak evidence",
        EVIDENCE_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "mission_ok_not_weak_evidence_rollup_v0_1.json",
    ),
    (
        "unsupported mission type rejected",
        SELECTOR_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "unsupported_mission_type_selector_output_v0_1.json",
    ),
    (
        "runtime flags remain false",
        SELECTOR_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "runtime_flags_enabled_selector_output_v0_1.json",
    ),
    (
        "production mission generation remains blocked",
        SELECTOR_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "production_generation_enabled_selector_output_v0_1.json",
    ),
    (
        "selector output contains no mission content",
        SELECTOR_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "selector_output_contains_mission_content_v0_1.json",
    ),
    (
        "graph context required for opportunity blobs",
        OPPORTUNITY_SCHEMA,
        NEGATIVE_FIXTURE_DIR / "missing_graph_context_opportunity_v0_1.json",
    ),
]


@dataclass
class ValidationResult:
    passes: list[str] = field(default_factory=list)
    failures: list[str] = field(default_factory=list)

    def pass_(self, message: str) -> None:
        self.passes.append(message)

    def fail(self, message: str) -> None:
        self.failures.append(message)

    @property
    def ok(self) -> bool:
        return not self.failures


def load_json(path: Path) -> Any:
    try:
        with path.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except FileNotFoundError:
        raise SystemExit(f"File not found: {path}") from None
    except json.JSONDecodeError as error:
        raise SystemExit(f"Invalid JSON in {path}: {error}") from None


def format_path(path_parts: Iterable[object]) -> str:
    parts = [str(part) for part in path_parts]
    return "/" + "/".join(parts) if parts else "/"


def jsonschema_tools() -> tuple[Any, Any] | tuple[None, None]:
    try:
        from jsonschema import Draft202012Validator, FormatChecker
    except ModuleNotFoundError:
        return None, None
    return Draft202012Validator, FormatChecker


def schema_errors(schema_path: Path, document: Any) -> list[str]:
    Draft202012Validator, FormatChecker = jsonschema_tools()
    if Draft202012Validator is None or FormatChecker is None:
        return [
            "jsonschema is required. Use `.venv/bin/python` or install "
            "`jsonschema` in the active Python environment."
        ]

    schema = load_json(schema_path)
    try:
        Draft202012Validator.check_schema(schema)
    except Exception as error:
        return [f"schema is invalid: {error}"]

    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    return [
        f"{format_path(error.path)}: {error.message}"
        for error in sorted(validator.iter_errors(document), key=lambda item: list(item.path))
    ]


def validate_json_schema(
    schema_path: Path,
    document_path: Path,
    label: str,
    result: ValidationResult,
) -> Any:
    document = load_json(document_path)
    errors = schema_errors(schema_path, document)
    if errors:
        for error in errors:
            result.fail(f"{label} schema {error}")
    else:
        result.pass_(f"{label} JSON Schema validation passed")
    return document


def expect_schema_failure(
    label: str,
    schema_path: Path,
    document_path: Path,
    result: ValidationResult,
) -> None:
    errors = schema_errors(schema_path, load_json(document_path))
    if errors:
        result.pass_(f"negative fixture rejected: {label}")
    else:
        result.fail(f"negative fixture unexpectedly passed: {label}")


def iter_dict_items(value: Any, path: str = "") -> Iterable[tuple[str, Any, str]]:
    if isinstance(value, dict):
        for key, child in value.items():
            pointer = f"{path}/{key}" if path else f"/{key}"
            yield key, child, pointer
            yield from iter_dict_items(child, pointer)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            yield from iter_dict_items(child, f"{path}/{index}" if path else f"/{index}")


def expect_false_flags(value: Any, result: ValidationResult, label: str) -> None:
    for key, child, pointer in iter_dict_items(value):
        if key in BLOCKED_FALSE_KEYS and child is not False:
            result.fail(f"{label} {pointer} must be false")


def expect_no_forbidden_content_keys(value: Any, result: ValidationResult, label: str) -> None:
    for key, _child, pointer in iter_dict_items(value):
        if key in FORBIDDEN_CONTENT_KEYS:
            result.fail(f"{label} includes forbidden production mission field {pointer}")


def expect_exact(value: Any, expected: Any, pointer: str, result: ValidationResult) -> None:
    if value != expected:
        result.fail(f"{pointer} must be {expected!r}; got {value!r}")


def validate_registry_domain(registry: dict[str, Any], result: ValidationResult) -> None:
    expect_exact(registry.get("global_top_k_opportunities"), 25, "/global_top_k_opportunities", result)
    expect_false_flags(registry, result, "registry")
    expect_no_forbidden_content_keys(registry, result, "registry")

    mission_types = registry.get("mission_types", [])
    mission_type_names = [entry.get("mission_type") for entry in mission_types if isinstance(entry, dict)]
    if mission_type_names != EXPECTED_MISSION_TYPES:
        result.fail("/mission_types must match the approved v0.1 mission type set in order")

    if len(set(mission_type_names)) != len(mission_type_names):
        result.fail("/mission_types contains duplicate mission_type values")

    by_band: dict[str, list[dict[str, Any]]] = {}
    for entry in mission_types:
        if not isinstance(entry, dict):
            continue
        floor = entry.get("score_floor")
        ceiling = entry.get("score_ceiling")
        if isinstance(floor, (int, float)) and isinstance(ceiling, (int, float)) and floor > ceiling:
            result.fail(f"{entry.get('mission_type')} score_floor must be <= score_ceiling")
        by_band.setdefault(str(entry.get("value_band")), []).append(entry)

    band_order = ["low", "lower_medium", "medium", "high", "very_high"]
    for index, band in enumerate(band_order[:-2]):
        lower_ceiling = max(
            (entry["score_ceiling"] for entry in by_band.get(band, []) if "score_ceiling" in entry),
            default=None,
        )
        upper_floor = min(
            (
                entry["score_floor"]
                for entry in by_band.get(band_order[index + 2], [])
                if "score_floor" in entry
            ),
            default=None,
        )
        if lower_ceiling is not None and upper_floor is not None and lower_ceiling > upper_floor:
            result.fail(
                f"{band} ceiling {lower_ceiling} cannot exceed "
                f"{band_order[index + 2]} floor {upper_floor}"
            )

    if result.ok:
        result.pass_("registry domain gates passed")


def validate_evidence_domain(evidence: dict[str, Any], result: ValidationResult) -> None:
    expect_false_flags(evidence, result, "evidence")
    expect_no_forbidden_content_keys(evidence, result, "evidence")

    signals = evidence.get("evidence_signals", [])
    saw_survey_ok = False
    saw_mission_ok = False

    for index, signal in enumerate(signals):
        if not isinstance(signal, dict):
            continue
        source_type = signal.get("source_type")
        raw_signal = signal.get("raw_signal")
        pointer = f"/evidence_signals/{index}"

        if source_type == "survey" and raw_signal == "ok":
            saw_survey_ok = True
            expect_exact(signal.get("signal_class"), "no_signal", f"{pointer}/signal_class", result)
            expect_exact(signal.get("signal_weight"), 0, f"{pointer}/signal_weight", result)
            expect_exact(
                signal.get("contributes_to_preference"),
                False,
                f"{pointer}/contributes_to_preference",
                result,
            )
            expect_exact(
                signal.get("can_support_non_failure"),
                False,
                f"{pointer}/can_support_non_failure",
                result,
            )

        if source_type in {"mission_review", "song_review"} and raw_signal == "ok":
            saw_mission_ok = True
            expect_exact(signal.get("signal_class"), "weak_non_failure", f"{pointer}/signal_class", result)
            weight = signal.get("signal_weight")
            if not isinstance(weight, (int, float)) or not 0 < weight <= 0.25:
                result.fail(f"{pointer}/signal_weight must be > 0 and <= 0.25 for review ok")
            expect_exact(
                signal.get("contributes_to_preference"),
                False,
                f"{pointer}/contributes_to_preference",
                result,
            )
            expect_exact(
                signal.get("can_support_non_failure"),
                True,
                f"{pointer}/can_support_non_failure",
                result,
            )

    if not saw_survey_ok:
        result.fail("positive evidence fixture must include a survey ok no-signal example")
    if not saw_mission_ok:
        result.fail("positive evidence fixture must include a mission/song-review ok weak example")

    artist_rollups = evidence.get("rollups", {}).get("by_artist", [])
    survey_ok_artist_rollup = next(
        (
            rollup
            for rollup in artist_rollups
            if rollup.get("rollup_id") == "rollup_artist_synthetic_target"
        ),
        None,
    )
    if survey_ok_artist_rollup is None:
        result.fail("missing survey-ok artist rollup proving ok is ignored")
    else:
        counts = survey_ok_artist_rollup.get("signal_counts", {})
        expect_exact(counts.get("survey_ok_ignored"), 1, "/rollups/by_artist/survey_ok_ignored", result)
        expect_exact(counts.get("total_preference_signals"), 0, "/rollups/by_artist/total_preference_signals", result)
        expect_exact(counts.get("total_non_failure_signals"), 0, "/rollups/by_artist/total_non_failure_signals", result)

    song_rollups = evidence.get("rollups", {}).get("by_song", [])
    mission_ok_song_rollup = next(
        (rollup for rollup in song_rollups if rollup.get("rollup_id") == "rollup_song_gateway_step"),
        None,
    )
    if mission_ok_song_rollup is None:
        result.fail("missing mission-ok song rollup proving weak non-failure")
    else:
        counts = mission_ok_song_rollup.get("signal_counts", {})
        expect_exact(counts.get("mission_ok_weak"), 1, "/rollups/by_song/mission_ok_weak", result)
        expect_exact(counts.get("total_preference_signals"), 0, "/rollups/by_song/total_preference_signals", result)
        expect_exact(counts.get("total_non_failure_signals"), 1, "/rollups/by_song/total_non_failure_signals", result)

    if result.ok:
        result.pass_("evidence reaction semantics gates passed")


def validate_opportunity_domain(
    opportunity: dict[str, Any],
    result: ValidationResult,
    label: str = "opportunity",
) -> None:
    expect_false_flags(opportunity, result, label)
    expect_no_forbidden_content_keys(opportunity, result, label)
    expect_exact(opportunity.get("opportunity_only"), True, f"{label}/opportunity_only", result)
    expect_exact(opportunity.get("construction_status"), "not_constructed", f"{label}/construction_status", result)

    graph_contexts = opportunity.get("graph_context_summary", {}).get("graph_contexts", [])
    if not isinstance(graph_contexts, list) or not graph_contexts:
        result.fail(f"{label}/graph_context_summary/graph_contexts must be non-empty")

    score = opportunity.get("score_components", {}).get("final_opportunity_score")
    if not isinstance(score, (int, float)) or not 0 <= score <= 1:
        result.fail(f"{label}/score_components/final_opportunity_score must be between 0 and 1")


def validate_selector_ranked_opportunities(selector: dict[str, Any], result: ValidationResult) -> None:
    opportunities = selector.get("ranked_opportunities", [])
    opportunity_schema = load_json(OPPORTUNITY_SCHEMA)
    Draft202012Validator, FormatChecker = jsonschema_tools()
    if Draft202012Validator is None or FormatChecker is None:
        result.fail("jsonschema is required to validate selector ranked opportunities")
        return

    validator = Draft202012Validator(opportunity_schema, format_checker=FormatChecker())
    previous_score: float | None = None

    for index, opportunity in enumerate(opportunities):
        item_errors = sorted(validator.iter_errors(opportunity), key=lambda error: list(error.path))
        if item_errors:
            for error in item_errors:
                result.fail(
                    "selector ranked opportunity "
                    f"/ranked_opportunities/{index}{format_path(error.path)}: {error.message}"
                )
            continue

        validate_opportunity_domain(opportunity, result, f"selector/ranked_opportunities/{index}")
        score = opportunity.get("score_components", {}).get("final_opportunity_score")
        if isinstance(score, (int, float)):
            if previous_score is not None and score > previous_score:
                result.fail("/ranked_opportunities must be sorted by descending final_opportunity_score")
            previous_score = score

    if not opportunities:
        result.fail("selector positive fixture must include at least one ranked opportunity")

    if result.ok:
        result.pass_("selector ranked opportunities satisfy opportunity schema")


def validate_selector_domain(selector: dict[str, Any], result: ValidationResult) -> None:
    expect_false_flags(selector, result, "selector")
    expect_no_forbidden_content_keys(selector, result, "selector")
    expect_exact(selector.get("opportunity_only"), True, "/opportunity_only", result)
    expect_exact(selector.get("global_top_k_opportunities"), 25, "/global_top_k_opportunities", result)
    expect_exact(selector.get("selector_audit", {}).get("heap_max_size"), 25, "/selector_audit/heap_max_size", result)
    expect_exact(
        selector.get("selector_audit", {}).get("selection_mode"),
        "offline_synthetic_fixture",
        "/selector_audit/selection_mode",
        result,
    )
    validate_selector_ranked_opportunities(selector, result)

    if result.ok:
        result.pass_("selector output gates passed")


def validate_type_files(result: ValidationResult) -> None:
    missing = [path for path in TYPE_FILES if not path.exists()]
    if missing:
        for path in missing:
            result.fail(f"missing TypeScript type file: {path.relative_to(REPO_ROOT)}")
        return

    blocked_substrings = [
        "MusicAtlasController",
        "supabase/functions",
        "mission_construction_v0_2",
        "mission_construction_contract_v0_2",
    ]
    for path in TYPE_FILES:
        text = path.read_text(encoding="utf-8")
        for blocked in blocked_substrings:
            if blocked in text:
                result.fail(f"{path.relative_to(REPO_ROOT)} must not import or reuse {blocked}")

    if result.ok:
        result.pass_("TypeScript selector contract files are present and offline-only")


def validate_contracts() -> ValidationResult:
    result = ValidationResult()

    registry = validate_json_schema(REGISTRY_SCHEMA, REGISTRY_FIXTURE, "mission type registry", result)
    evidence = validate_json_schema(EVIDENCE_SCHEMA, EVIDENCE_FIXTURE, "evidence rollup", result)
    opportunity = validate_json_schema(OPPORTUNITY_SCHEMA, OPPORTUNITY_FIXTURE, "mission opportunity blob", result)
    selector = validate_json_schema(SELECTOR_SCHEMA, SELECTOR_FIXTURE, "selector output", result)

    validate_registry_domain(registry, result)
    validate_evidence_domain(evidence, result)
    validate_opportunity_domain(opportunity, result)
    if result.ok:
        result.pass_("mission opportunity blob gates passed")
    validate_selector_domain(selector, result)
    validate_type_files(result)

    for label, schema_path, document_path in NEGATIVE_CASES:
        expect_schema_failure(label, schema_path, document_path, result)

    return result


def main() -> int:
    result = validate_contracts()
    for message in result.passes:
        print(f"PASS {message}")
    for message in result.failures:
        print(f"FAIL {message}", file=sys.stderr)
    return 0 if result.ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
